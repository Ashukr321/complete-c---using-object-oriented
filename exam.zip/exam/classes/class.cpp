// here we see the what is the class in the  cpp 

// class ⭐
    // -> inline class
    // static member  ⭐
    // instance member or variables

// object 
    //  how to create object 
    // array of object 

// inheritance 

    // types  of inheritance 

      //simple inheritance 
      // multilelble 
      // mulitple 
      // hirericle  // tree binaray 
      // hybrid   // 

// polymorphism  
        
      // -> method overloading 
      // -> frined fuction 
      //   vitual fuction 
  

// access modifire or visibility 
    // public  +  > access to
    // private  -  > likha nahi rahta hai  default 
    // protected  #
