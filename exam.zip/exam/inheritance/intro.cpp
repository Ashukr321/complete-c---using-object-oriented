// inheritance 
// inherit 

// a -> add , 100 // base class 
//class b -> mulit, add // derived class 

// types 

// simple inheritance  // ⭐⭐
// multilelvel inheritance 
// multiple    ⭐⭐
// hybrid 
// hirerical 

// trick  sh2m2 
// s -> 
// h -> 
// h 
// m
// m 

